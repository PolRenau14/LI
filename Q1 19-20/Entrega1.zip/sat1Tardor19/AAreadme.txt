Resuelve los siguientes ejercicios, siguiendo el ejemplo de miSudoku.pl.
Para mayor comodidad, usa el Makefile que genera el ejecutable "miSudoku".
De más fácil a más difícil:

-teams.pl
-events.pl
-bus.pl
